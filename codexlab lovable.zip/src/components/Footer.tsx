import { Link } from "@tanstack/react-router";
import { Sparkles, Mail, MessageCircle, Github, Twitter, Linkedin, Instagram } from "lucide-react";

export function Footer() {
  return (
    <footer className="relative mt-32 border-t border-white/5">
      <div className="absolute inset-x-0 -top-px h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
      <div className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <Link to="/" className="flex items-center gap-2">
              <div className="rounded-lg p-1.5" style={{ background: "var(--gradient-primary)" }}>
                <Sparkles className="h-4 w-4 text-primary-foreground" />
              </div>
              <span className="font-display text-lg font-semibold">
                Codex<span className="text-gradient">Lab</span>
              </span>
            </Link>
            <p className="mt-4 text-sm text-muted-foreground leading-relaxed">
              Building the AI infrastructure that powers tomorrow's most ambitious companies.
            </p>
            <div className="flex gap-3 mt-6">
              {[Twitter, Linkedin, Github, Instagram].map((Icon, i) => (
                <a key={i} href="#" className="p-2 rounded-lg glass hover:border-primary/40 transition-all" aria-label="Social">
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-sm font-semibold mb-4">Services</h4>
            <ul className="space-y-2.5 text-sm text-muted-foreground">
              <li><Link to="/services" className="hover:text-foreground transition-colors">AI Automation</Link></li>
              <li><Link to="/services" className="hover:text-foreground transition-colors">SaaS Development</Link></li>
              <li><Link to="/services" className="hover:text-foreground transition-colors">AI Agents</Link></li>
              <li><Link to="/services" className="hover:text-foreground transition-colors">Workflow Automation</Link></li>
              <li><Link to="/services" className="hover:text-foreground transition-colors">AI Integrations</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold mb-4">Company</h4>
            <ul className="space-y-2.5 text-sm text-muted-foreground">
              <li><Link to="/about" className="hover:text-foreground transition-colors">About</Link></li>
              <li><Link to="/portfolio" className="hover:text-foreground transition-colors">Case Studies</Link></li>
              <li><Link to="/pricing" className="hover:text-foreground transition-colors">Pricing</Link></li>
              <li><Link to="/book" className="hover:text-foreground transition-colors">Book a Meeting</Link></li>
              <li><Link to="/privacy" className="hover:text-foreground transition-colors">Privacy Policy</Link></li>
              <li><Link to="/terms" className="hover:text-foreground transition-colors">Terms & Conditions</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold mb-4">Get in touch</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li>
                <a href="mailto:codexlabofficial@gmail.com" className="flex items-center gap-2 hover:text-foreground transition-colors">
                  <Mail className="h-4 w-4" /> codexlabofficial@gmail.com
                </a>
              </li>
              <li>
                <a href="https://wa.me/10000000000" className="flex items-center gap-2 hover:text-foreground transition-colors">
                  <MessageCircle className="h-4 w-4" /> WhatsApp Chat
                </a>
              </li>
              <li>
                <Link to="/contact" className="btn-ghost !py-2 !px-4 text-xs mt-3 inline-flex">
                  Contact us
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-muted-foreground">
          <p>© {new Date().getFullYear()} Codex Lab. Engineering the autonomous future.</p>
          <p>Made with precision, deployed with confidence.</p>
        </div>
      </div>
    </footer>
  );
}
