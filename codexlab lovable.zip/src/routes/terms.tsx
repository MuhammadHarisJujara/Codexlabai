import { createFileRoute } from "@tanstack/react-router";
import { PageShell, PageHero } from "@/components/PageShell";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms & Conditions — Codex Lab" },
      { name: "description", content: "The terms governing your use of the Codex Lab website and services." },
      { property: "og:url", content: "/terms" },
    ],
    links: [{ rel: "canonical", href: "/terms" }],
  }),
  component: Terms,
});

function Terms() {
  return (
    <PageShell>
      <PageHero eyebrow="Legal" title="Terms & Conditions" subtitle="Last updated: January 2026" />
      <section className="mx-auto max-w-3xl px-6 pb-20">
        <article className="glass-strong rounded-2xl p-8 space-y-6 text-muted-foreground leading-relaxed">
          <S t="1. Acceptance">By accessing codexlab.com or engaging Codex Lab for services, you agree to these terms.</S>
          <S t="2. Services">Codex Lab provides AI automation, SaaS development, AI agent engineering, workflow automation, and related services. Specific deliverables, timelines, and pricing are defined in a signed Statement of Work.</S>
          <S t="3. Payment">Unless otherwise agreed, invoices are due net 14. Retainer fees are billed monthly in advance. Overdue accounts may pause delivery.</S>
          <S t="4. Intellectual property">Upon full payment, you own all custom code, configurations, and models we deliver. Codex Lab retains rights to its general methodologies, frameworks, and pre-existing tools.</S>
          <S t="5. Confidentiality">Each party agrees to protect the other's confidential information with reasonable care. Mutual NDAs are available on request.</S>
          <S t="6. Warranties">Services are provided with reasonable skill and care. We do not warrant uninterrupted operation of third-party APIs or platforms outside our control.</S>
          <S t="7. Liability">To the maximum extent permitted by law, neither party is liable for indirect or consequential damages. Total liability is limited to fees paid in the 12 months preceding the claim.</S>
          <S t="8. Termination">Either party may terminate with 30 days written notice. Fees for work completed prior to termination remain due.</S>
          <S t="9. Governing law">These terms are governed by the laws of the jurisdiction in which Codex Lab is incorporated. Disputes are resolved by binding arbitration.</S>
          <S t="10. Contact">codexlabofficial@gmail.com</S>
        </article>
      </section>
    </PageShell>
  );
}

function S({ t, children }: { t: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="text-foreground font-semibold text-lg mb-2">{t}</h2>
      <p>{children}</p>
    </div>
  );
}
