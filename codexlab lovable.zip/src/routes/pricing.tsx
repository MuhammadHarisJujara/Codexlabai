import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell, PageHero } from "@/components/PageShell";
import { Reveal, StaggerGroup, StaggerItem } from "@/components/Reveal";
import { CheckCircle2, Sparkles } from "lucide-react";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing — Codex Lab" },
      { name: "description", content: "Transparent, outcome-based pricing for AI automation, SaaS development, and AI agent engagements." },
      { property: "og:title", content: "Pricing — Codex Lab" },
      { property: "og:description", content: "Plans built around your stage. Outcomes guaranteed." },
      { property: "og:url", content: "/pricing" },
    ],
    links: [{ rel: "canonical", href: "/pricing" }],
  }),
  component: Pricing,
});

const plans = [
  {
    name: "Launch",
    price: "$4,900",
    sub: "starting · one-time",
    desc: "A single automation or agent, designed and shipped in 2–3 weeks.",
    features: ["One scoped automation or agent", "Discovery + architecture", "Deployment + handoff", "30 days of support"],
    cta: "Start with Launch",
  },
  {
    name: "Scale",
    price: "$9,800",
    sub: "/ month",
    desc: "Embedded AI team for ongoing builds, integrations, and optimization.",
    features: ["Dedicated senior engineer", "Up to 4 active workstreams", "Weekly shipping cadence", "Priority response SLA", "Quarterly strategy reviews"],
    cta: "Talk to us",
    featured: true,
  },
  {
    name: "SaaS",
    price: "Custom",
    sub: "fixed-bid or retainer",
    desc: "Full SaaS product builds from spec to scale, including infra and billing.",
    features: ["End-to-end product engineering", "Modern stack + Stripe + auth", "Cloud infrastructure included", "Post-launch optimization", "Equity option for select projects"],
    cta: "Scope a project",
  },
];

function Pricing() {
  return (
    <PageShell>
      <PageHero
        eyebrow="Pricing"
        title="Built for serious operators."
        subtitle="No surprise invoices. No staffing games. Every engagement is scoped, fixed, and outcome-driven."
      />

      <section className="mx-auto max-w-7xl px-6 py-12">
        <StaggerGroup className="grid md:grid-cols-3 gap-5">
          {plans.map((p) => (
            <StaggerItem key={p.name}>
              <div className={`relative rounded-2xl p-8 h-full transition-all duration-500 ${
                p.featured
                  ? "glass-strong border-primary/40 scale-[1.02]"
                  : "card-glow"
              }`}>
                {p.featured && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium" style={{ background: "var(--gradient-primary)" }}>
                    <Sparkles className="h-3 w-3" /> Most popular
                  </div>
                )}
                <div className="text-sm text-muted-foreground">{p.name}</div>
                <div className="mt-3 flex items-baseline gap-1">
                  <span className="text-4xl font-display font-semibold text-gradient">{p.price}</span>
                  <span className="text-sm text-muted-foreground">{p.sub}</span>
                </div>
                <p className="mt-3 text-sm text-muted-foreground">{p.desc}</p>
                <ul className="mt-6 space-y-2.5">
                  {p.features.map((f) => (
                    <li key={f} className="text-sm flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Link to="/book" className={`mt-8 w-full ${p.featured ? "btn-primary" : "btn-ghost"}`}>
                  {p.cta}
                </Link>
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </section>

      <section className="mx-auto max-w-3xl px-6 py-16 text-center">
        <Reveal>
          <p className="text-sm text-muted-foreground">
            Need something different? Equity arrangements, paid pilots, and bespoke engagements are all on the table.
          </p>
          <Link to="/contact" className="btn-ghost mt-6">Contact us</Link>
        </Reveal>
      </section>
    </PageShell>
  );
}
