import { createFileRoute } from "@tanstack/react-router";
import { PageShell, PageHero } from "@/components/PageShell";
import { Reveal } from "@/components/Reveal";
import { Mail, MessageCircle, MapPin, Send } from "lucide-react";
import { useState } from "react";
import { z } from "zod";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Codex Lab" },
      { name: "description", content: "Get in touch with Codex Lab. Reach us via the contact form, email, or WhatsApp." },
      { property: "og:title", content: "Contact Codex Lab" },
      { property: "og:description", content: "Talk to the team behind your next AI system." },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: Contact,
});

const schema = z.object({
  name: z.string().trim().min(1, "Required").max(100),
  email: z.string().trim().email("Invalid email").max(255),
  company: z.string().trim().max(120).optional(),
  message: z.string().trim().min(10, "Tell us a bit more").max(2000),
});

// Replace with real Formspree endpoint
const FORMSPREE_ENDPOINT = "https://formspree.io/f/your-form-id";

function Contact() {
  const [status, setStatus] = useState<"idle" | "sending" | "ok" | "err">("idle");
  const [errors, setErrors] = useState<Record<string, string>>({});

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErrors({});
    const fd = new FormData(e.currentTarget);
    const data = Object.fromEntries(fd) as Record<string, string>;
    const parsed = schema.safeParse(data);
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      parsed.error.issues.forEach((i) => { errs[String(i.path[0])] = i.message; });
      setErrors(errs);
      return;
    }
    setStatus("sending");
    try {
      const res = await fetch(FORMSPREE_ENDPOINT, {
        method: "POST",
        headers: { "Accept": "application/json", "Content-Type": "application/json" },
        body: JSON.stringify({ ...parsed.data, _subject: "New Codex Lab inquiry" }),
      });
      setStatus(res.ok ? "ok" : "err");
      if (res.ok) (e.target as HTMLFormElement).reset();
    } catch {
      setStatus("err");
    }
  }

  return (
    <PageShell>
      <PageHero
        eyebrow="Contact"
        title="Tell us what you're building."
        subtitle="Reply within one business day. Often faster."
      />

      <section className="mx-auto max-w-6xl px-6 py-12 grid lg:grid-cols-5 gap-8">
        <Reveal className="lg:col-span-2 space-y-4">
          <div className="card-glow">
            <Mail className="h-5 w-5 text-primary mb-3" />
            <h3 className="font-semibold">Email</h3>
            <a href="mailto:codexlabofficial@gmail.com" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              codexlabofficial@gmail.com
            </a>
          </div>
          <div className="card-glow">
            <MessageCircle className="h-5 w-5 text-primary mb-3" />
            <h3 className="font-semibold">WhatsApp</h3>
            <a href="https://wa.me/10000000000" target="_blank" rel="noopener" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Chat with us on WhatsApp
            </a>
          </div>
          <div className="card-glow">
            <MapPin className="h-5 w-5 text-primary mb-3" />
            <h3 className="font-semibold">Worldwide</h3>
            <p className="text-sm text-muted-foreground">Remote team. Clients across NA, EU, MENA, and APAC.</p>
          </div>
        </Reveal>

        <Reveal className="lg:col-span-3">
          <form onSubmit={onSubmit} className="glass-strong rounded-2xl p-6 md:p-8 space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <Field name="name" label="Full name" error={errors.name} />
              <Field name="email" label="Email" type="email" error={errors.email} />
            </div>
            <Field name="company" label="Company (optional)" error={errors.company} />
            <div>
              <label className="text-sm text-muted-foreground">What are you trying to build?</label>
              <textarea
                name="message"
                rows={5}
                className="mt-1.5 w-full rounded-lg bg-white/[0.03] border border-white/10 px-4 py-3 text-sm focus:outline-none focus:border-primary/50 focus:bg-white/[0.05] transition-all"
                placeholder="A few sentences is plenty…"
              />
              {errors.message && <p className="text-xs text-destructive mt-1">{errors.message}</p>}
            </div>
            <button type="submit" disabled={status === "sending"} className="btn-primary w-full disabled:opacity-50">
              {status === "sending" ? "Sending…" : (<>Send message <Send className="h-4 w-4" /></>)}
            </button>
            {status === "ok" && <p className="text-sm text-primary text-center">Thanks — we'll reply within one business day.</p>}
            {status === "err" && <p className="text-sm text-destructive text-center">Something went wrong. Email us directly at codexlabofficial@gmail.com.</p>}
          </form>
        </Reveal>
      </section>
    </PageShell>
  );
}

function Field({ name, label, type = "text", error }: { name: string; label: string; type?: string; error?: string }) {
  return (
    <div>
      <label className="text-sm text-muted-foreground">{label}</label>
      <input
        name={name}
        type={type}
        className="mt-1.5 w-full rounded-lg bg-white/[0.03] border border-white/10 px-4 py-3 text-sm focus:outline-none focus:border-primary/50 focus:bg-white/[0.05] transition-all"
      />
      {error && <p className="text-xs text-destructive mt-1">{error}</p>}
    </div>
  );
}
