import { createFileRoute } from "@tanstack/react-router";
import { PageShell, PageHero } from "@/components/PageShell";
import { Reveal } from "@/components/Reveal";
import { Calendar, Clock, Video, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/book")({
  head: () => ({
    meta: [
      { title: "Book a Meeting — Codex Lab" },
      { name: "description", content: "Schedule a free 30-minute strategy call with the Codex Lab team. No sales pitch — just a working session." },
      { property: "og:title", content: "Book a meeting — Codex Lab" },
      { property: "og:description", content: "Free 30-minute AI automation strategy call." },
      { property: "og:url", content: "/book" },
    ],
    links: [{ rel: "canonical", href: "/book" }],
  }),
  component: Book,
});

// Replace with real Calendly URL
const CALENDLY_URL = "https://calendly.com/codexlab/30min";

function Book() {
  return (
    <PageShell>
      <PageHero
        eyebrow="Book a meeting"
        title="A 30-minute working session."
        subtitle="No slide decks. No sales pitch. We'll map your highest-leverage AI opportunity live, then send notes."
      />

      <section className="mx-auto max-w-6xl px-6 py-8 grid lg:grid-cols-5 gap-6">
        <Reveal className="lg:col-span-2 space-y-3">
          {[
            { icon: Clock, t: "30 minutes", d: "Tight, focused, respectful of your time." },
            { icon: Video, t: "Google Meet / Zoom", d: "Sent automatically after booking." },
            { icon: Calendar, t: "Same-week availability", d: "We hold slots open across timezones." },
          ].map((x) => (
            <div key={x.t} className="card-glow">
              <x.icon className="h-5 w-5 text-primary mb-3" />
              <h3 className="font-semibold">{x.t}</h3>
              <p className="text-sm text-muted-foreground mt-1">{x.d}</p>
            </div>
          ))}
          <div className="card-glow">
            <h3 className="font-semibold mb-3">What you'll walk away with</h3>
            <ul className="space-y-2">
              {[
                "A clear picture of where AI fits in your stack",
                "One concrete automation worth $100k+ annually",
                "A scoped proposal if there's a fit",
              ].map((x) => (
                <li key={x} className="flex items-start gap-2 text-sm text-muted-foreground">
                  <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  {x}
                </li>
              ))}
            </ul>
          </div>
        </Reveal>

        <Reveal className="lg:col-span-3">
          <div className="glass-strong rounded-2xl p-2 h-[700px] overflow-hidden">
            <iframe
              src={CALENDLY_URL}
              className="w-full h-full rounded-xl bg-background"
              title="Book a meeting with Codex Lab"
              loading="lazy"
            />
          </div>
          <p className="text-xs text-muted-foreground text-center mt-4">
            Prefer email? Reach us at{" "}
            <a href="mailto:codexlabofficial@gmail.com" className="text-primary hover:underline">codexlabofficial@gmail.com</a>
          </p>
        </Reveal>
      </section>
    </PageShell>
  );
}
