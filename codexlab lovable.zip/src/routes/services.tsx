import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell, PageHero } from "@/components/PageShell";
import { StaggerGroup, StaggerItem, Reveal } from "@/components/Reveal";
import {
  Bot, Mic, Headphones, Layout, Calendar, Workflow, GitBranch, Target,
  ArrowRight, CheckCircle2,
} from "lucide-react";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — AI Automation, SaaS & Agents | Codex Lab" },
      { name: "description", content: "AI chatbots, voice agents, customer support automation, SaaS apps, appointment systems, workflow & CRM automation, and lead-gen systems." },
      { property: "og:title", content: "Services — Codex Lab" },
      { property: "og:description", content: "End-to-end AI engineering: agents, automations, SaaS." },
      { property: "og:url", content: "/services" },
    ],
    links: [{ rel: "canonical", href: "/services" }],
  }),
  component: Services,
});

const pillars = [
  { title: "AI Automation Solutions", desc: "Replace manual ops with autonomous systems that scale with zero headcount." },
  { title: "SaaS Product Development", desc: "Custom SaaS from spec to scale — auth, billing, dashboards, infra." },
  { title: "AI Agents Development", desc: "Agents that reason, act, and integrate with your tools and data." },
  { title: "Business Workflow Automation", desc: "Unify your stack. Eliminate the swivel-chair work." },
  { title: "AI Integrations", desc: "Drop AI into the tools your team already lives in — without rebuilding." },
];

const services = [
  { icon: Bot, title: "AI Chatbots", bullets: ["Custom-trained on your data", "Multi-channel deployment", "Handoff to human seamlessly"] },
  { icon: Mic, title: "AI Voice Agents", bullets: ["Outbound + inbound calls", "Booking & qualification", "Natural conversation flow"] },
  { icon: Headphones, title: "AI Customer Support", bullets: ["Tier-1 resolution at scale", "Multilingual", "CSAT analytics dashboard"] },
  { icon: Layout, title: "SaaS Web Applications", bullets: ["Modern stack (React, Node, edge)", "Stripe billing baked in", "Built for 100k+ users"] },
  { icon: Calendar, title: "AI Appointment Systems", bullets: ["Smart calendar sync", "Auto-reschedule & reminders", "No-show prevention AI"] },
  { icon: Workflow, title: "Workflow Automation", bullets: ["Cross-tool orchestration", "Error monitoring", "Self-healing pipelines"] },
  { icon: GitBranch, title: "CRM Automation", bullets: ["Pipeline auto-updates", "Deal scoring & summaries", "HubSpot / Salesforce / Pipedrive"] },
  { icon: Target, title: "AI Lead Generation", bullets: ["Sourcing & enrichment", "Personalized outreach", "Reply handling"] },
];

function Services() {
  return (
    <PageShell>
      <PageHero
        eyebrow="Capabilities"
        title="Production AI. End to end."
        subtitle="From a single workflow to an entire AI-native product line — we design, build, and operate the systems."
      />

      <section className="mx-auto max-w-7xl px-6 py-12">
        <StaggerGroup className="grid md:grid-cols-2 lg:grid-cols-5 gap-3">
          {pillars.map((p) => (
            <StaggerItem key={p.title}>
              <div className="glass rounded-xl p-5 h-full">
                <div className="text-xs text-primary font-mono mb-2">{String(pillars.indexOf(p) + 1).padStart(2, "0")}</div>
                <h3 className="font-semibold">{p.title}</h3>
                <p className="mt-2 text-xs text-muted-foreground">{p.desc}</p>
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16">
        <Reveal className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-semibold">What we ship</h2>
          <p className="mt-3 text-muted-foreground">Eight production-grade service tracks. Mix and match.</p>
        </Reveal>
        <StaggerGroup className="grid md:grid-cols-2 gap-4">
          {services.map((s) => (
            <StaggerItem key={s.title}>
              <div className="card-glow h-full">
                <div className="flex items-start gap-4">
                  <div className="inline-flex p-3 rounded-xl shrink-0" style={{ background: "var(--gradient-primary)" }}>
                    <s.icon className="h-5 w-5 text-primary-foreground" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg">{s.title}</h3>
                    <ul className="mt-3 space-y-1.5">
                      {s.bullets.map((b) => (
                        <li key={b} className="text-sm text-muted-foreground flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                          {b}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </section>

      <section className="mx-auto max-w-5xl px-6 py-20 text-center">
        <Reveal>
          <div className="glass-strong rounded-3xl p-10">
            <h2 className="text-3xl md:text-4xl font-semibold">Not sure where to start?</h2>
            <p className="mt-3 text-muted-foreground">A 30-minute call is all we need to map your highest-leverage opportunity.</p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Link to="/book" className="btn-primary">Book free consultation <ArrowRight className="h-4 w-4" /></Link>
              <Link to="/pricing" className="btn-ghost">See pricing</Link>
            </div>
          </div>
        </Reveal>
      </section>
    </PageShell>
  );
}
