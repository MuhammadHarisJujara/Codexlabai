import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell, PageHero } from "@/components/PageShell";
import { Reveal, StaggerGroup, StaggerItem } from "@/components/Reveal";
import { ArrowUpRight, TrendingUp } from "lucide-react";

export const Route = createFileRoute("/portfolio")({
  head: () => ({
    meta: [
      { title: "Case Studies — Codex Lab" },
      { name: "description", content: "Real AI automation and SaaS deployments — measured by revenue, retention, and reclaimed hours." },
      { property: "og:title", content: "Portfolio — Codex Lab" },
      { property: "og:description", content: "Selected case studies in AI automation and SaaS development." },
      { property: "og:url", content: "/portfolio" },
    ],
    links: [{ rel: "canonical", href: "/portfolio" }],
  }),
  component: Portfolio,
});

const cases = [
  {
    client: "Helix Bio",
    tag: "Workflow Automation",
    title: "Replaced 14 manual ops workflows in 6 weeks",
    metrics: [{ k: "Hours/week saved", v: "320+" }, { k: "Error rate", v: "−94%" }],
    grad: "from-cyan-500/20 to-blue-600/20",
  },
  {
    client: "Stratus",
    tag: "AI Voice Agent",
    title: "Outbound voice agent closing demos at 2.3× SDR rate",
    metrics: [{ k: "Demos booked/mo", v: "1,840" }, { k: "Cost per demo", v: "−71%" }],
    grad: "from-violet-500/20 to-pink-500/20",
  },
  {
    client: "Lumen",
    tag: "Support Automation",
    title: "Tier-1 support resolved by AI at 83% containment",
    metrics: [{ k: "CSAT lift", v: "+22 pts" }, { k: "Response time", v: "8s avg" }],
    grad: "from-emerald-500/20 to-teal-500/20",
  },
  {
    client: "Northwind",
    tag: "Custom SaaS",
    title: "Built logistics SaaS from spec to 12k MAU in 5 months",
    metrics: [{ k: "Active users", v: "12,400" }, { k: "Uptime", v: "99.98%" }],
    grad: "from-orange-500/20 to-rose-500/20",
  },
  {
    client: "Quantum",
    tag: "AI Lead Generation",
    title: "Autonomous outbound system replacing 4-person SDR team",
    metrics: [{ k: "Pipeline added", v: "$4.2M" }, { k: "Reply rate", v: "11.4%" }],
    grad: "from-fuchsia-500/20 to-purple-600/20",
  },
  {
    client: "Acuity",
    tag: "CRM Automation",
    title: "Self-updating CRM eliminating 100% of manual data entry",
    metrics: [{ k: "Data accuracy", v: "99.6%" }, { k: "Sales velocity", v: "+34%" }],
    grad: "from-sky-500/20 to-indigo-500/20",
  },
];

function Portfolio() {
  return (
    <PageShell>
      <PageHero
        eyebrow="Selected work"
        title="Quiet wins. Real numbers."
        subtitle="A few of the systems we've shipped recently. Names public with permission; many of the best stay behind NDAs."
      />

      <section className="mx-auto max-w-7xl px-6 py-12">
        <StaggerGroup className="grid md:grid-cols-2 gap-5">
          {cases.map((c) => (
            <StaggerItem key={c.client}>
              <div className="card-glow h-full relative overflow-hidden group cursor-pointer">
                <div className={`absolute inset-0 bg-gradient-to-br ${c.grad} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
                <div className="relative">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-xs text-primary font-mono">{c.tag}</div>
                      <div className="text-2xl font-display font-semibold mt-1">{c.client}</div>
                    </div>
                    <ArrowUpRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:rotate-12 transition-all" />
                  </div>
                  <p className="mt-6 text-foreground/90 leading-relaxed">{c.title}</p>
                  <div className="mt-6 grid grid-cols-2 gap-3">
                    {c.metrics.map((m) => (
                      <div key={m.k} className="rounded-lg bg-white/[0.03] border border-white/5 p-3">
                        <div className="text-xs text-muted-foreground">{m.k}</div>
                        <div className="text-xl font-semibold text-gradient mt-1 inline-flex items-center gap-1">
                          {m.v}
                          <TrendingUp className="h-4 w-4" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </section>

      <section className="mx-auto max-w-4xl px-6 py-20 text-center">
        <Reveal>
          <h2 className="text-3xl md:text-4xl font-semibold">Your case study, next.</h2>
          <div className="mt-8">
            <Link to="/book" className="btn-primary">Start your project</Link>
          </div>
        </Reveal>
      </section>
    </PageShell>
  );
}
