import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  ArrowRight, Bot, Workflow, Cpu, Sparkles, Zap, MessageSquare,
  Mic, Headphones, Layout, Calendar, GitBranch, Users, Target,
  ShieldCheck, Rocket, Star, CheckCircle2,
} from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { Reveal, StaggerGroup, StaggerItem } from "@/components/Reveal";
import { Counter } from "@/components/Counter";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Codex Lab — AI Automation & SaaS Development Studio" },
      { name: "description", content: "We design and ship AI automation, custom SaaS, and intelligent agents that compound revenue for ambitious teams." },
      { property: "og:title", content: "Codex Lab — AI Automation Studio" },
      { property: "og:description", content: "AI automation, SaaS, and intelligent agents engineered for scale." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Home,
});

const services = [
  { icon: Bot, title: "AI Chatbots", desc: "Conversational agents that resolve 80% of tier-1 support without breaking character." },
  { icon: Mic, title: "AI Voice Agents", desc: "Human-grade phone agents that book, qualify, and follow up — 24/7." },
  { icon: Headphones, title: "Customer Support Automation", desc: "Routing, triage, summarization, and CSAT lift across every channel." },
  { icon: Layout, title: "SaaS Web Applications", desc: "Production-grade SaaS built from spec to scale, with auth, billing, and ops." },
  { icon: Calendar, title: "AI Appointment Systems", desc: "Self-driving scheduling that fills calendars and eliminates no-shows." },
  { icon: Workflow, title: "Workflow Automation", desc: "Connect your stack. Replace 40+ hours of manual ops every week." },
  { icon: GitBranch, title: "CRM Automation", desc: "Pipelines that update themselves, deals that surface themselves." },
  { icon: Target, title: "AI Lead Generation", desc: "Outbound systems that source, enrich, and warm leads on autopilot." },
];

const stats = [
  { v: 120, suf: "+", label: "Production deployments" },
  { v: 42, suf: "M+", label: "Automated actions/month" },
  { v: 99, suf: "%", label: "Uptime SLA" },
  { v: 8, suf: "x", label: "Average ROI in 90 days" },
];

const logos = ["Northwind", "Acuity", "Vertex AI", "Stratus", "Helix", "Quantum", "Lumen"];

const process = [
  { n: "01", t: "Discovery", d: "We map your workflows, surface friction, and quantify the opportunity." },
  { n: "02", t: "Architecture", d: "We design the AI + automation stack tailored to your data and team." },
  { n: "03", t: "Build", d: "Senior engineers ship in weeks, not quarters. You see progress daily." },
  { n: "04", t: "Scale", d: "We monitor, optimize, and expand systems as your business compounds." },
];

const testimonials = [
  { name: "Sarah Chen", role: "COO, Helix Bio", quote: "Codex Lab replaced 14 manual workflows in 6 weeks. Our ops team got their nights back." },
  { name: "Marcus Webb", role: "Founder, Stratus", quote: "The AI voice agent they built closes more demos than my SDR team did last quarter." },
  { name: "Priya Nair", role: "Head of CX, Lumen", quote: "Our CSAT jumped 22 points. Customers genuinely think they're talking to a person." },
];

function Home() {
  return (
    <PageShell>
      {/* HERO */}
      <section className="relative mx-auto max-w-7xl px-6 pt-8 pb-24 text-center overflow-hidden">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass text-xs font-medium text-muted-foreground"
        >
          <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
          AI engineering studio · Booking Q2 cohort
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mt-8 text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-semibold tracking-tighter leading-[0.95]"
        >
          <span className="text-gradient">AI systems that</span>
          <br />
          <span className="text-foreground">run your business</span>
          <br />
          <span className="text-gradient">while you sleep.</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mt-8 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed"
        >
          Codex Lab is the engineering partner behind AI automations, SaaS products, and
          autonomous agents for companies that refuse to scale linearly.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.35 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <Link to="/book" className="btn-primary">
            Book a Free Consultation <ArrowRight className="h-4 w-4" />
          </Link>
          <Link to="/services" className="btn-ghost">Get Started</Link>
        </motion.div>

        {/* Dashboard mock */}
        <motion.div
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="mt-20 mx-auto max-w-5xl"
        >
          <div className="relative rounded-2xl glass-strong p-2 shadow-2xl">
            <div className="absolute -inset-px rounded-2xl bg-gradient-to-r from-primary/30 via-accent/30 to-primary/30 opacity-50 blur-xl -z-10" />
            <div className="rounded-xl bg-background/80 p-6 md:p-8">
              <div className="flex items-center gap-2 mb-6">
                <div className="flex gap-1.5">
                  <span className="h-3 w-3 rounded-full bg-red-500/60" />
                  <span className="h-3 w-3 rounded-full bg-yellow-500/60" />
                  <span className="h-3 w-3 rounded-full bg-green-500/60" />
                </div>
                <div className="ml-4 text-xs text-muted-foreground font-mono">codexlab.ai/dashboard</div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { l: "Active agents", v: "24", c: "primary" },
                  { l: "Tasks today", v: "8,421", c: "accent" },
                  { l: "Hours saved", v: "1,204", c: "primary" },
                  { l: "Revenue lift", v: "+38%", c: "accent" },
                ].map((s, i) => (
                  <motion.div
                    key={s.l}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.7 + i * 0.08 }}
                    className="rounded-lg bg-white/[0.03] border border-white/5 p-4 text-left"
                  >
                    <div className="text-xs text-muted-foreground">{s.l}</div>
                    <div className="text-2xl font-semibold mt-1 text-gradient">{s.v}</div>
                    <div className="mt-3 h-1 rounded-full bg-white/5 overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${60 + i * 10}%` }}
                        transition={{ delay: 1 + i * 0.1, duration: 1.2 }}
                        className="h-full"
                        style={{ background: "var(--gradient-primary)" }}
                      />
                    </div>
                  </motion.div>
                ))}
              </div>
              <div className="mt-6 grid md:grid-cols-3 gap-3 text-left">
                {["Lead enrichment pipeline · running", "Voice agent v3 · 1.2k calls today", "Workflow sync · Salesforce ↔ Notion"].map((t, i) => (
                  <motion.div
                    key={t}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 1.2 + i * 0.1 }}
                    className="flex items-center gap-2 text-xs text-muted-foreground px-3 py-2 rounded-md bg-white/[0.02] border border-white/5"
                  >
                    <span className="h-1.5 w-1.5 rounded-full bg-green-400 animate-pulse" />
                    {t}
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* TRUSTED BY */}
      <section className="mx-auto max-w-7xl px-6 py-12">
        <Reveal>
          <p className="text-center text-xs uppercase tracking-[0.2em] text-muted-foreground mb-8">
            Trusted by teams shipping faster than yesterday
          </p>
          <div className="flex flex-wrap items-center justify-center gap-x-12 gap-y-4 opacity-60">
            {logos.map((l) => (
              <span key={l} className="font-display text-lg md:text-xl font-semibold tracking-tight text-muted-foreground hover:text-foreground transition-colors">
                {l}
              </span>
            ))}
          </div>
        </Reveal>
      </section>

      {/* STATS */}
      <section className="mx-auto max-w-7xl px-6 py-20">
        <StaggerGroup className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((s) => (
            <StaggerItem key={s.label}>
              <div className="card-glow text-center">
                <div className="text-4xl md:text-5xl font-semibold text-gradient font-display">
                  <Counter to={s.v} suffix={s.suf} />
                </div>
                <div className="mt-2 text-sm text-muted-foreground">{s.label}</div>
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </section>

      {/* SERVICES */}
      <section className="mx-auto max-w-7xl px-6 py-24">
        <Reveal className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs text-muted-foreground mb-4">
            <Cpu className="h-3 w-3" /> Capabilities
          </div>
          <h2 className="text-4xl md:text-5xl font-semibold tracking-tight">
            <span className="text-gradient">Every system</span> your team should never build twice.
          </h2>
          <p className="mt-4 text-muted-foreground">
            We build, deploy, and operate AI-native systems end-to-end.
          </p>
        </Reveal>
        <StaggerGroup className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {services.map((s) => (
            <StaggerItem key={s.title}>
              <div className="card-glow h-full group">
                <div className="inline-flex p-2.5 rounded-lg mb-4" style={{ background: "var(--gradient-primary)" }}>
                  <s.icon className="h-5 w-5 text-primary-foreground" />
                </div>
                <h3 className="font-semibold text-lg">{s.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
                <div className="mt-4 text-xs text-primary opacity-0 group-hover:opacity-100 transition-opacity inline-flex items-center gap-1">
                  Learn more <ArrowRight className="h-3 w-3" />
                </div>
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </section>

      {/* PROCESS */}
      <section className="mx-auto max-w-7xl px-6 py-24">
        <Reveal className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-4xl md:text-5xl font-semibold tracking-tight">
            A process built for <span className="text-gradient">velocity</span>.
          </h2>
          <p className="mt-4 text-muted-foreground">From first call to production in weeks.</p>
        </Reveal>
        <StaggerGroup className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {process.map((p) => (
            <StaggerItem key={p.n}>
              <div className="card-glow h-full relative overflow-hidden">
                <div className="absolute -top-4 -right-4 text-7xl font-display font-bold text-white/[0.04]">{p.n}</div>
                <div className="relative">
                  <div className="text-xs font-mono text-primary">{p.n}</div>
                  <h3 className="font-semibold text-lg mt-2">{p.t}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{p.d}</p>
                </div>
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </section>

      {/* TESTIMONIALS */}
      <section className="mx-auto max-w-7xl px-6 py-24">
        <Reveal className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-semibold tracking-tight">
            Operators who <span className="text-gradient">don't compromise</span>.
          </h2>
        </Reveal>
        <StaggerGroup className="grid md:grid-cols-3 gap-4">
          {testimonials.map((t) => (
            <StaggerItem key={t.name}>
              <div className="card-glow h-full flex flex-col">
                <div className="flex gap-0.5 mb-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-foreground/90 leading-relaxed flex-1">"{t.quote}"</p>
                <div className="mt-6 pt-4 border-t border-white/5">
                  <div className="font-semibold text-sm">{t.name}</div>
                  <div className="text-xs text-muted-foreground">{t.role}</div>
                </div>
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-5xl px-6 py-24">
        <Reveal>
          <div className="relative rounded-3xl glass-strong p-10 md:p-16 text-center overflow-hidden">
            <div className="absolute inset-0 bg-aurora opacity-50" />
            <div className="relative">
              <div className="inline-flex p-3 rounded-2xl mb-6" style={{ background: "var(--gradient-primary)" }}>
                <Rocket className="h-6 w-6 text-primary-foreground" />
              </div>
              <h2 className="text-4xl md:text-5xl font-semibold tracking-tight">
                Ready to <span className="text-gradient">automate the impossible</span>?
              </h2>
              <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
                Free 30-minute strategy call. We'll map at least one automation opportunity worth $100k+ annually.
              </p>
              <div className="mt-8 flex flex-wrap justify-center gap-3">
                <Link to="/book" className="btn-primary">Book a Free Consultation <ArrowRight className="h-4 w-4" /></Link>
                <Link to="/contact" className="btn-ghost">Talk to sales</Link>
              </div>
              <div className="mt-8 flex flex-wrap justify-center gap-6 text-xs text-muted-foreground">
                {["No-obligation discovery", "NDA on request", "Senior engineers only"].map((x) => (
                  <span key={x} className="inline-flex items-center gap-1.5">
                    <CheckCircle2 className="h-3.5 w-3.5 text-primary" /> {x}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </Reveal>
      </section>
    </PageShell>
  );
}
