import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell, PageHero } from "@/components/PageShell";
import { Reveal, StaggerGroup, StaggerItem } from "@/components/Reveal";
import { Target, Compass, Zap, Heart, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Codex Lab" },
      { name: "description", content: "We're a small team of senior AI engineers building automation systems for companies that refuse to scale linearly." },
      { property: "og:title", content: "About Codex Lab" },
      { property: "og:description", content: "Meet the AI engineering studio behind production-grade automations and SaaS." },
      { property: "og:url", content: "/about" },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
  component: About,
});

const values = [
  { icon: Target, t: "Outcomes, not output", d: "We measure ourselves by your revenue, retention, and reclaimed hours — never lines of code." },
  { icon: Compass, t: "Principled engineering", d: "Production-grade from day one. We don't ship demos pretending to be products." },
  { icon: Zap, t: "Ruthless velocity", d: "Senior engineers, small teams, daily progress. No layers of project managers." },
  { icon: Heart, t: "Long-term partnership", d: "We stay invested long after launch. Most clients work with us for years." },
];

function About() {
  return (
    <PageShell>
      <PageHero
        eyebrow="About Codex Lab"
        title="We engineer the systems other agencies pretend to."
        subtitle="Codex Lab is an AI engineering studio for companies that have outgrown wrappers, prompts, and templates. We build the deep systems."
      />

      <section className="mx-auto max-w-4xl px-6 py-12">
        <Reveal>
          <div className="glass-strong rounded-2xl p-8 md:p-12">
            <h2 className="text-2xl md:text-3xl font-semibold mb-4">Our story</h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Codex Lab was founded by a small group of engineers who'd spent years inside high-growth
                companies watching the same pattern: AI projects that died in the gap between a polished
                demo and a production system that actually worked at 3am.
              </p>
              <p>
                We started Codex Lab to close that gap. Today we partner with founders, operators, and
                engineering leaders to design, ship, and operate AI automations and custom SaaS products
                that compound — quietly, reliably, profitably.
              </p>
              <p>
                We're small on purpose. Every engagement runs with senior engineers, no handoffs, and a
                level of craft you can only get from a team that owns its work end-to-end.
              </p>
            </div>
          </div>
        </Reveal>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-20">
        <Reveal className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-semibold">What we believe</h2>
        </Reveal>
        <StaggerGroup className="grid md:grid-cols-2 gap-4">
          {values.map((v) => (
            <StaggerItem key={v.t}>
              <div className="card-glow h-full">
                <div className="inline-flex p-2.5 rounded-lg mb-4" style={{ background: "var(--gradient-primary)" }}>
                  <v.icon className="h-5 w-5 text-primary-foreground" />
                </div>
                <h3 className="font-semibold text-lg">{v.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{v.d}</p>
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </section>

      <section className="mx-auto max-w-5xl px-6 py-20 text-center">
        <Reveal>
          <h2 className="text-3xl md:text-4xl font-semibold">Let's build something inevitable.</h2>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/book" className="btn-primary">Book a call <ArrowRight className="h-4 w-4" /></Link>
            <Link to="/services" className="btn-ghost">See our services</Link>
          </div>
        </Reveal>
      </section>
    </PageShell>
  );
}
