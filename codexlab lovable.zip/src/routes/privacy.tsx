import { createFileRoute } from "@tanstack/react-router";
import { PageShell, PageHero } from "@/components/PageShell";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — Codex Lab" },
      { name: "description", content: "How Codex Lab collects, uses, and protects your information." },
      { property: "og:url", content: "/privacy" },
    ],
    links: [{ rel: "canonical", href: "/privacy" }],
  }),
  component: Privacy,
});

function Privacy() {
  return (
    <PageShell>
      <PageHero eyebrow="Legal" title="Privacy Policy" subtitle="Last updated: January 2026" />
      <section className="mx-auto max-w-3xl px-6 pb-20">
        <article className="prose-invert glass-strong rounded-2xl p-8 space-y-6 text-muted-foreground leading-relaxed">
          <Section title="1. Information we collect">
            We collect information you provide directly: name, email, company, and message contents when you contact us, book a call, or sign up for a service. We also collect basic analytics about your visit (pages, referrer, device) using privacy-respecting tooling.
          </Section>
          <Section title="2. How we use your information">
            To respond to inquiries, deliver our services, send relevant updates, and improve the site. We never sell your data. We never train external AI models on your data without explicit consent.
          </Section>
          <Section title="3. Sharing">
            We share information only with the processors required to deliver our services (email, scheduling, analytics, cloud infrastructure). Each is bound by GDPR-grade data processing terms.
          </Section>
          <Section title="4. Security">
            We follow industry-standard practices: encryption in transit and at rest, scoped access controls, and regular reviews. No system is perfectly secure, but we treat your data like our own.
          </Section>
          <Section title="5. Your rights">
            You can request access, correction, or deletion of your data at any time. Email codexlabofficial@gmail.com and we'll respond within 30 days.
          </Section>
          <Section title="6. Cookies">
            We use essential cookies and privacy-respecting analytics. No third-party advertising cookies.
          </Section>
          <Section title="7. Updates">
            We may update this policy occasionally. We'll change the date at the top and, for material changes, notify users by email.
          </Section>
          <Section title="8. Contact">
            Questions? Email codexlabofficial@gmail.com.
          </Section>
        </article>
      </section>
    </PageShell>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="text-foreground font-semibold text-lg mb-2">{title}</h2>
      <p>{children}</p>
    </div>
  );
}
