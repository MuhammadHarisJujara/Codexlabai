import { createFileRoute } from "@tanstack/react-router";
import { PageShell, PageHero } from "@/components/PageShell";
import { motion } from "framer-motion";
import { useState } from "react";
import { Plus } from "lucide-react";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — Codex Lab" },
      { name: "description", content: "Answers to the questions teams ask before working with Codex Lab on AI automation and SaaS development." },
      { property: "og:title", content: "FAQ — Codex Lab" },
      { property: "og:description", content: "Common questions about pricing, timelines, NDAs, and engagements." },
      { property: "og:url", content: "/faq" },
    ],
    links: [{ rel: "canonical", href: "/faq" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "FAQPage",
        mainEntity: faqs.map(f => ({
          "@type": "Question",
          name: f.q,
          acceptedAnswer: { "@type": "Answer", text: f.a },
        })),
      }),
    }],
  }),
  component: FAQ,
});

const faqs = [
  { q: "How long does a typical project take?", a: "Most automation or agent builds ship in 2–4 weeks. Full SaaS products typically run 8–16 weeks depending on scope. We share a concrete timeline after our discovery call." },
  { q: "Do you sign NDAs?", a: "Yes. We sign mutual NDAs on request before any discovery work begins." },
  { q: "Who owns the code and the IP?", a: "You do — fully, including source, infrastructure configs, and any models we train or fine-tune for you." },
  { q: "Which AI providers do you work with?", a: "OpenAI, Anthropic, Google, open-source (Llama, Mistral), and self-hosted models. We pick what's best for your latency, cost, and privacy constraints — not what's trendy." },
  { q: "Can you integrate with our existing stack?", a: "Almost certainly. We've shipped integrations with Salesforce, HubSpot, Notion, Slack, Zendesk, Intercom, Stripe, Snowflake, and dozens more." },
  { q: "What happens after launch?", a: "Every engagement includes a support period. Most clients move into our Scale plan for ongoing optimization, monitoring, and new builds." },
  { q: "Do you offer fixed pricing?", a: "Yes. Launch projects are fixed-bid. Scale is a flat monthly retainer. SaaS engagements can be fixed-bid or retainer depending on scope clarity." },
  { q: "How do I get started?", a: "Book a free 30-minute consultation. We'll map your highest-leverage opportunity and quote scoped work on the spot." },
];

function FAQ() {
  return (
    <PageShell>
      <PageHero
        eyebrow="Frequently asked"
        title="The fine print, up front."
        subtitle="What teams want to know before kicking off."
      />
      <section className="mx-auto max-w-3xl px-6 py-12">
        <div className="space-y-3">
          {faqs.map((f, i) => <Item key={i} q={f.q} a={f.a} />)}
        </div>
      </section>
    </PageShell>
  );
}

function Item({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className={`rounded-xl glass overflow-hidden transition-all ${open ? "border-primary/30" : ""}`}>
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between gap-4 p-5 text-left hover:bg-white/[0.02]"
      >
        <span className="font-medium">{q}</span>
        <motion.div animate={{ rotate: open ? 45 : 0 }} className="shrink-0">
          <Plus className="h-5 w-5 text-primary" />
        </motion.div>
      </button>
      <motion.div
        initial={false}
        animate={{ height: open ? "auto" : 0, opacity: open ? 1 : 0 }}
        className="overflow-hidden"
      >
        <p className="px-5 pb-5 text-sm text-muted-foreground leading-relaxed">{a}</p>
      </motion.div>
    </div>
  );
}
